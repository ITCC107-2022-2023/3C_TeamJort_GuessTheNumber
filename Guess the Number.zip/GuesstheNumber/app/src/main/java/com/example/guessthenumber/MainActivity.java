package com.example.guessthenumber;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewPropertyAnimator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashSet;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    int result;
    Set<Integer> guessedNumbers;

    static int getRandomNumber(int max, int min) {
        return (int) ((Math.random() * (max - min + 1)) + min);
    }

    public void makeToast(String str) {
        Toast toast = Toast.makeText(MainActivity.this, str, Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, 200);
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.show();


        final View toastView = toast.getView();
        toastView.setAlpha(0f);
        ViewPropertyAnimator animator = toastView.animate()
                .alpha(1f)
                .setDuration(500)
                .setInterpolator(new AccelerateDecelerateInterpolator());
        animator.start();
    }

    public void resetGame() {
        int min = 1;
        int max = 10;
        result = getRandomNumber(min, max);
        guessedNumbers.clear();
    }

    public void clickFunction(View view) {
        EditText variable = findViewById(R.id.editId);
        int userGuessing = Integer.parseInt(variable.getText().toString());

        if (userGuessing < 1 || userGuessing > 10) {
            makeToast("Please Enter A Number Between 1 To 10");
        } else if (guessedNumbers.contains(userGuessing)) {
            makeToast("You Already Used The Number " + userGuessing + ", Try Another Number");
        } else {
            guessedNumbers.add(userGuessing);

            if (userGuessing < result) {
                makeToast("Think of a Higher Number, Try Again");
            } else if (userGuessing > result) {
                makeToast("Think of a Lower Number, Try Again");
            } else {
                makeToast("Congratulations, You Guessed the Number!");
                resetGame();
            }
        }
        variable.setText("");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        guessedNumbers = new HashSet<>();
        resetGame();
    }
}
